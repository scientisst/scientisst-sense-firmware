#include "main.h"
#include "bt.h"
#include "macros.h"
#include "timer.h"
#include "gpio.h"
#include "spi.h"

#define BT_SEND_PRIORITY_TASK 40
#define ACQ_PRIORITY_TASK 3
#define I2C_ACQ_PRIORITY_TASK 1

void acqAdc1Task();
void acqI2cTask();

TaskHandle_t acquiring_1_task;
TaskHandle_t acquiring_i2c_task;

//BT
uint32_t bt_client = 0;
char bt_device_name[17] = BT_DEFAULT_DEVICE_NAME;

//COM
uint8_t snd_buff[2][MAX_BUFFER_SIZE];           //Data structure to hold the data to be sent through bluetooth        
uint16_t snd_buff_idx[2] = {0, 0};                  
uint8_t active_snd_buff = 0;
uint8_t packet_size = 0;
uint8_t cong_flag = 0;

DRAM_ATTR const uint8_t crc_table[16] = {0, 3, 6, 5, 12, 15, 10, 9, 11, 8, 13, 14, 7, 4, 1, 2};
uint8_t crc_seq = 0;
const uint8_t packet_size_num_chs[DEFAULT_ADC_CHANNELS+1] = {0, 3, 4, 6, 7, 7, 8};       //Table that has the packet size in function of the number of channels 

//ADC
DRAM_ATTR const uint8_t analog_channels[DEFAULT_ADC_CHANNELS] = {A0_ADC_CH, A1_ADC_CH, A2_ADC_CH, A3_ADC_CH, A4_ADC_CH, A5_ADC_CH};
uint8_t active_chs[DEFAULT_ADC_CHANNELS] = {0, 0, 0, 0, 0, 0};  //If all channels are active: = {5, 4, 3, 2, 1, 0}
uint8_t num_active_chs = 0;
uint8_t live_mode = 0;                                  //Flag that indicastes if live mode (acquiring) is on    
uint32_t sample_rate = DEFAULT_SAMPLE_RATE;    
esp_adc_cal_characteristics_t adc1_chars;     

//I2C
I2c_Sensor_State i2c_sensor_values;

//SPI
spi_device_handle_t ads_spi_handler;

//TODO: DEBUG ONLY VARIABLES!
struct timeval begin, end;

void app_main(void){ 
    //Inicialize send buffers
    for(uint8_t i = 0; i < 2; i++){
        memset(snd_buff[i], 0, MAX_BUFFER_SIZE);
    }
    
    xTaskCreatePinnedToCore(&initBt, "initBtTask", DEFAULT_TASK_STACK_SIZE, NULL, BT_SEND_PRIORITY_TASK, NULL, 0);

    //Create the 1st task that will acquire data from adc. This task will be responsible for acquiring the data from adc1
    xTaskCreatePinnedToCore(&acqAdc1Task, "acqAdc1Task", DEFAULT_TASK_STACK_SIZE, NULL, ACQ_PRIORITY_TASK, &acquiring_1_task, 1);

    //Create the 1st task that will acquire data from i2c. This task will be responsible for acquiring the data from i2c
    //xTaskCreatePinnedToCore(&acqI2cTask, "acqI2cTask", DEFAULT_TASK_STACK_SIZE, NULL, I2C_ACQ_PRIORITY_TASK, &acquiring_i2c_task, 1);

    vTaskDelete(NULL);
}
 
//Task that adc reads using adc1, it's also the main task of CPU1 (APP CPU)
void acqAdc1Task(){
    uint8_t* rx_data_ads = NULL;

    spi_transaction_t ads_trans;
    spi_transaction_t *ads_rtrans;

    //Init Timer 0_1 (timer 1 from group 0) and register it's interupt handler
    timerGrpInit(TIMER_GROUP_USED, TIMER_IDX_USED, timerGrp0Isr);

    //Config all possible adc channels
    initAdc(ADC_RESOLUTION);
    gpioInit();
    //TODO: Tirar IO_21: só está aqui para dar ground ao ads
    gpio_set_level(GPIO_NUM_21, 0);

    //24 status bits + 24 bits x 2 channels = 9bytes required. But DMA buffer needs to be 32bit aligned
    rx_data_ads = heap_caps_malloc(3*sizeof(uint32_t), MALLOC_CAP_DMA);  
    memset(rx_data_ads, 0, 9);
    adsInit();
    adsSetupRoutine();
    adsSetSamplingRate(250);
    adsConfigureChannels(1);
    memset(&ads_trans, 0, sizeof(ads_trans));   //zero out the transaction
    ads_trans.length = 72;                   //send nothing
    ads_trans.rxlength = 72;                //24 status bits + 24 bits x 2 channels
    ads_trans.tx_buffer = NULL;             //skip write phase
    ads_trans.rx_buffer = rx_data_ads;
    
    while(1){
        //spi_device_queue_trans(ads_spi_handler, &ads_trans, portMAX_DELAY);

        if(ulTaskNotifyTake(pdTRUE, portMAX_DELAY)){
            //Check if active snd_buff is full
            if(snd_buff_idx[active_snd_buff] + packet_size >= MAX_BUFFER_SIZE){
                DEBUG_PRINT_W("acqAdc1Task", "Sending buffer is full, cannot acquire");
                continue;
            }
            
            acquireAdc1Channels(snd_buff[active_snd_buff]+snd_buff_idx[active_snd_buff]);
            calcCrc(snd_buff[active_snd_buff]+snd_buff_idx[active_snd_buff]);

            //spi_device_get_trans_result(ads_spi_handler, &ads_rtrans, portMAX_DELAY);
            //uint8_t* recv_ads = ads_rtrans->rx_buffer;
            //int swag = (recv_ads[3] << 16) | ((uint8_t)recv_ads[4] << 8) | (recv_ads[5]);
            //printf("Raw:%d, Voltage:%f\n", swag, (double)swag*(3.3/16777216));
            
            snd_buff_idx[active_snd_buff] += packet_size;

            if(!cong_flag){
                sendData();
            }

        }else{
            DEBUG_PRINT_W("acqAdc1", "ulTaskNotifyTake timed out!");
        }
    }
}

void acqI2cTask(){
    /*uint16_t heart_rate;
    uint16_t oxygen;
    uint8_t confidence;*/
    uint32_t test;

    i2cMasterInit();
    MAX32664_Init();    
    if(MAX32664_Config()){
        DEBUG_PRINT_E("MAX32664_Config", "Config failed");
    }

    //Init Timer 1_1 (timer 1 from group 1) and register it's interupt handler
    timerGrpInit(TIMER_GRP_ACQ_I2C, TIMER_IDX_ACQ_I2C, timerGrp1Isr);
    timerStart(TIMER_GRP_ACQ_I2C, TIMER_IDX_ACQ_I2C, ACQ_I2C_SAMPLE_RATE);

    while(1){
        if(ulTaskNotifyTake(pdTRUE, portMAX_DELAY)){
            
            gettimeofday(&begin, NULL); 
            while((end.tv_sec - begin.tv_sec) + ((end.tv_usec - begin.tv_usec)/1000000.0) < 0.08){
                gettimeofday(&end, NULL);
                test++;
                vTaskDelay(10/portTICK_RATE_MS);
            }
            //printf("Time elapsed %f s\n", ((end.tv_sec - begin.tv_sec) + ((end.tv_usec - begin.tv_usec)/1000000.0)));

            /*MLX90614_GetTempObj(MLX90614_DEFAULT_ADDRESS, &(i2c_sensor_values.temp_obj), &(i2c_sensor_values.temp_obj_int));
            MLX90614_GetTempAmb(MLX90614_DEFAULT_ADDRESS, &(i2c_sensor_values.temp_amb), &(i2c_sensor_values.temp_amb_int));
            MAX32664_GetBPM(&heart_rate, &oxygen, &confidence, &(i2c_sensor_values.status));
            if(confidence >= CONFIDENCE_THRESHOLD){
                i2c_sensor_values.heart_rate = heart_rate;
                i2c_sensor_values.oxygen = oxygen;
                i2c_sensor_values.confidence = confidence;
            }*/

            //printf("BPM:%d, SpO2:%d, Confidence:%d, Status:%d, Temp Object:%.1f, Temp Ambient:%.1f\n", i2c_sensor_values.heart_rate, i2c_sensor_values.oxygen, i2c_sensor_values.confidence, i2c_sensor_values.status, i2c_sensor_values.temp_obj, i2c_sensor_values.temp_amb);
        }else{
            DEBUG_PRINT_W("acqI2cTask", "ulTaskNotifyTake timed out!");
        }
    }
}