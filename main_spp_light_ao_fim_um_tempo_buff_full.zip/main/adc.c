#include "adc.h"
#include "macros.h"
#include "com.h"
#include "freertos/FreeRTOS.h"
#include "main.h"


#define DEFAULT_VREF 1100



/*
    TUTORIAL: PRODUCE MASKS:
    ((1 << fieldLength) - 1) << (fieldIndex);               //fieldIndex >= 0
Example:        2                    2

    =   00001100
             ^
         fieldIndex
baseado em: https://stackoverflow.com/questions/11815894/how-to-read-write-arbitrary-bits-in-c-c
*/

void configAdc(int adc_index, int adc_resolution, int adc_channel){
    int dummy;
    esp_err_t ret;
    
    if(adc_index == 1){
        adc1_config_channel_atten(adc_channel, ADC_ATTEN_DB_11);        //Atennuation to get a input voltage of 0 to 2.6V
    }else if(adc_index == 2){
        adc2_config_channel_atten(adc_channel, ADC_ATTEN_DB_11);
        ret = adc2_get_raw(adc_channel, ADC_RESOLUTION, &dummy);
        if (ret == ESP_ERR_TIMEOUT){
            DEBUG_PRINT_E("configAdc", "CAN'T USE ADC2, WIFI IS ENABLED");
        }
    }
}

void initAdc(uint8_t adc_resolution){
    uint8_t i;
    

    //Check if TP is burned into eFuse
    if (esp_adc_cal_check_efuse(ESP_ADC_CAL_VAL_EFUSE_TP) == ESP_OK) {
        DEBUG_PRINT_I("eFuse Two Point: Supported\n");
    } else {
        DEBUG_PRINT_W("eFuse Two Point: NOT supported");
    }

    //Check Vref is burned into eFuse
    if (esp_adc_cal_check_efuse(ESP_ADC_CAL_VAL_EFUSE_VREF) == ESP_OK) {
        DEBUG_PRINT_I("eFuse Vref: Supported\n");
    } else {
        DEBUG_PRINT_W("eFuse Vref: NOT supported\n");
    }

    //Configure only adc1 resolution (it's not done per channel)
    adc1_config_width(ADC_RESOLUTION);

    //Configure each adc channel
    for(i = 0; i < DEFAULT_ADC_CHANNELS; i++){
        configAdc(1, adc_resolution, analog_channels[i]);     //i%2 will produce the following sequence: 0 1 0 1 0 1
    }

    //Characterize ADC
    esp_adc_cal_characterize(ADC_UNIT_1, ADC_ATTEN_DB_11, ADC_WIDTH_BIT_10, DEFAULT_VREF, &adc1_chars);


}

//Acquires and stores into frame the channel acquisitions
void IRAM_ATTR  acquireAdc1Channels(uint8_t* frame){
    uint16_t adc_res[6] = {0, 0, 0, 0, 0, 0};
    uint8_t i;
    
    //DEBUG_PRINT_I("acquireAdc1Channels", "num_channels = %d", num_active_chs);
    //DEBUG_PRINT_I("acquireAdc1Channels", "Writing on byte = %d", frame - snd_buff[active_snd_buff]);
 
    for(i = 0; i < num_active_chs; i++){
        adc_res[i] = adc1_get_raw(analog_channels[active_chs[i]]);
        DEBUG_PRINT_I("acquireAdc1Channels", "(adc_res)A%d=%d", active_chs[i], adc_res[i]);
    }

    //TODO
    /*uint32_t teste = adc1_get_raw(A0_ADC_CH);
    printf("A0 raw:%d voltage: %d\n\n", teste, esp_adc_cal_raw_to_voltage(teste, &adc1_chars));
    teste = adc1_get_raw(A1_ADC_CH);
    printf("A1 raw:%d voltage: %d\n\n", teste, esp_adc_cal_raw_to_voltage(teste, &adc1_chars));
    teste = adc1_get_raw(A2_ADC_CH);
    printf("A2 raw:%d voltage: %d\n\n", teste, esp_adc_cal_raw_to_voltage(teste, &adc1_chars));
    uint32_t teste = adc1_get_raw(A3_ADC_CH);
    printf("A3 raw:%d voltage: %d\n\n", teste, esp_adc_cal_raw_to_voltage(teste, &adc1_chars));
    teste = adc1_get_raw(A4_ADC_CH);
    printf("A4 raw:%d voltage: %d\n\n", teste, esp_adc_cal_raw_to_voltage(teste, &adc1_chars));
    teste = adc1_get_raw(A5_ADC_CH);
    printf("A5 raw:%d voltage: %d\n\n", teste, esp_adc_cal_raw_to_voltage(teste, &adc1_chars));*/
    

    *(uint16_t*)(frame+packet_size-3) |= adc_res[num_active_chs-1] << 2;
    if (num_active_chs > 1)
            *(uint16_t*)(frame+packet_size-4) |= adc_res[num_active_chs-2];
    if (num_active_chs > 2)
            *(uint16_t*)(frame+packet_size-6) |= adc_res[num_active_chs-3] << 6;
    if (num_active_chs > 3)
            *(uint16_t*)(frame+packet_size-7) |= adc_res[num_active_chs-4] << 4;
    if (num_active_chs > 4)
            *(uint16_t*)frame |= (adc_res[num_active_chs-5] & 0x3F0) << 2;  //Only the 6 upper bits of the 10-bit value are used
    if (num_active_chs > 5)
        frame[0] |= adc_res[num_active_chs-6] >> 4;                         //Only the 6 upper bits of the 10-bit value are used
    
    /*if(num_active_chs != 6){        //If less than 6 channels are used, no need to reduce A4 and A5's resolution
        *(uint16_t*)(frame) |= adc_res[0];
        if (num_active_chs > 1){
            *(uint16_t*)(frame+1) |= adc_res[1] << 2;
        }
        if (num_active_chs > 2){
            *(uint16_t*)(frame+2) |= adc_res[2] << 4;
        }
        if (num_active_chs > 3){
            *(uint16_t*)(frame+3) |= adc_res[3] << 6;
        }
        if (num_active_chs > 4){
            *(uint16_t*)(frame+5) |= adc_res[4];
        }
    }else{
        *(uint16_t*)(frame) |= adc_res[0] >> 4;
        *(uint16_t*)(frame) |= (adc_res[1] >> 4) << 6;
        *(uint16_t*)(frame+1) |= adc_res[2] << 4;
        *(uint16_t*)(frame+2) |= adc_res[3] << 6;
        *(uint16_t*)(frame+4) |= adc_res[4];
        *(uint16_t*)(frame+5) |= adc_res[5] << 2;
    }*/
    

    /**(uint16_t*)(frame+5) |= adc_res[0] << 2; 
    if (num_active_chs > 1){
        *(uint16_t*)(frame+4) |= adc_res[1];
    }
    if (num_active_chs > 2){
        *(uint16_t*)(frame+2) |= adc_res[2] << 6;
    }
    if (num_active_chs > 3){
        *(uint16_t*)(frame+1) |= adc_res[3] << 4;
    }
    if (num_active_chs > 4){
        *(uint16_t*)frame |= (adc_res[4] & 0x3F0) << 2;
    }
    if (num_active_chs > 5){
        frame[0] |= adc_res[5] >> 4;
    }
    */
}

void IRAM_ATTR calcCrc(uint8_t* frame){
    uint8_t crc = 0;
    uint8_t i;

    //calculate CRC (except last byte (seq+CRC) )
    for(i = 0; i < packet_size-1; i++){
        // calculate CRC nibble by nibble
        CALC_BYTE_CRC(crc, frame[i], crc_table);
    }

    //calculate CRC for last byte (seq+CRC)
    crc = crc_table[crc] ^ (crc_seq & 0x0F);
    crc = (crc_seq << 4) | crc_table[crc];

    //store CRC and Seq in the last byte of the packet
    frame[packet_size-1] = crc;

    crc_seq++;
}
