#ifndef _COM_H
#define _COM_H

#include <stdio.h>

#define DEFAULT_ADC_CHANNELS 6          //Default number of active adc channels
#define NUM_UNUSED_BITS_FOR_CH_MASK 2   //It's the number explained below

#define STATUS_PACKET_SIZE 16

typedef struct{
    uint8_t start_byte;
    uint8_t start_bit;
    uint8_t size;
}Packet_Cfg_t;

#define ADC1_CFG_IDX 0
#define ADC2_CFG_IDX 1

#define GET_NEXT_POS(curr_pos, dist)({\
    curr_pos.start_byte += (curr_pos.start_bit + dist)/8;      \
    curr_pos.start_bit = (curr_pos.start_bit + dist)%8;      \
})

void processRcv(uint8_t* buff, int buff_size);
void selectChsFromMask(uint8_t* buff);
void stopAcquisition(void);
void sendStatusPacket();
void sendFirmwareVersionPacket();

/*          MASK CONFIGURATION EXAMPLE
*                       bits
*           7   6   5   4   3   2   1   0
*           A6  A5  A4  A3  A2  A1  X   X
*           <--------------------><------>
*           DEFAULT_ADC_CHANNELS
*                        NUM_UNUSED_BITS_FOR_CH_MASK
*/

#endif