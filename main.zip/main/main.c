#include "main.h"
#include "bt.h"
#include "macros.h"
#include "timer.h"
#include "gpio.h"
#include "spi.h"

#define BT_SEND_PRIORITY_TASK 40
#define ACQ_PRIORITY_TASK 3
#define I2C_ACQ_PRIORITY_TASK 1

void acqAdc1Task();
void sendBtTask();
void acqI2cTask();

TaskHandle_t bt_send_task;
TaskHandle_t acquiring_2_task;
TaskHandle_t acquiring_1_task;
TaskHandle_t acquiring_i2c_task;
SemaphoreHandle_t active_snd_buff_mutex;
SemaphoreHandle_t bt_send_ready_sem;

//BT
uint32_t bt_client = 0;
char bt_device_name[17] = BT_DEFAULT_DEVICE_NAME;

//COM
uint8_t snd_buff[2][MAX_BUFFER_SIZE];           //Data structure to hold the data to be sent through bluetooth        
uint8_t snd_buff_idx[2] = {0, 0};                  
uint8_t active_snd_buff = 0;
uint8_t packet_size = 0;

DRAM_ATTR const uint8_t crc_table[16] = {0, 3, 6, 5, 12, 15, 10, 9, 11, 8, 13, 14, 7, 4, 1, 2};
uint8_t crc_seq = 0;
const uint8_t packet_size_num_chs[DEFAULT_ADC_CHANNELS+1] = {0, 3, 4, 6, 7, 7, 8};       //Table that has the packet size in function of the number of channels 

//ADC
DRAM_ATTR const uint8_t analog_channels[DEFAULT_ADC_CHANNELS] = {A0_ADC_CH, A1_ADC_CH, A2_ADC_CH, A3_ADC_CH, A4_ADC_CH, A5_ADC_CH};
uint8_t active_chs[DEFAULT_ADC_CHANNELS] = {0, 0, 0, 0, 0, 0};  //If all channels are active: = {5, 4, 3, 2, 1, 0}
uint8_t num_active_chs = 0;
uint8_t live_mode = 0;                                  //Flag that indicastes if live mode (acquiring) is on    
uint32_t sample_rate = DEFAULT_SAMPLE_RATE;    
esp_adc_cal_characteristics_t adc1_chars;     

//I2C
I2c_Sensor_State i2c_sensor_values;

//SPI
spi_device_handle_t ads_spi_handler;

//TODO: DEBUG ONLY VARIABLES!
struct timeval begin, end;
//unsigned int packet_cnt = 0;

void app_main(void){
    // Create a mutex type semaphore
    if((active_snd_buff_mutex = xSemaphoreCreateMutex()) == NULL){
        DEBUG_PRINT_E("xSemaphoreCreateMutex", "Mutex creation failed");
        abort();
    }

    // Create a mutex type semaphore
    if((bt_send_ready_sem = xSemaphoreCreateBinary()) == NULL){
        DEBUG_PRINT_E("xSemaphoreCreateBinary", "Semaphore creation failed");
        abort();
    }
    
    //Inicialize send buffers
    for(uint8_t i = 0; i < 2; i++){
        memset(snd_buff[i], 0, MAX_BUFFER_SIZE);
    }
    
    xTaskCreatePinnedToCore(&sendBtTask, "sendBtTask", DEFAULT_TASK_STACK_SIZE, NULL, BT_SEND_PRIORITY_TASK, &bt_send_task, 0);

    //Create the 1st task that will acquire data from adc. This task will be responsible for acquiring the data from adc1
    xTaskCreatePinnedToCore(&acqAdc1Task, "acqAdc1Task", DEFAULT_TASK_STACK_SIZE, NULL, ACQ_PRIORITY_TASK, &acquiring_1_task, 1);

    //Create the 1st task that will acquire data from i2c. This task will be responsible for acquiring the data from i2c
    //xTaskCreatePinnedToCore(&acqI2cTask, "acqI2cTask", DEFAULT_TASK_STACK_SIZE, NULL, I2C_ACQ_PRIORITY_TASK, &acquiring_i2c_task, 1);

    //Create the 2nd task that will acquire data from adc. This task will be responsible for acquiring the data from adc2
    //xTaskCreate(&acqAdc2Task, "acqAdc2Task", DEFAULT_TASK_STACK_SIZE, NULL, ACQ_PRIORITY_TASK, &acquiring_2_task);

    vTaskDelete(NULL);

}

//Starting task in CPU0 (PRO CPU)
void sendBtTask(){
    uint8_t sending_snd_buff;

    getDeviceName();
    initBt();
    
    while(1){
        //Waiting for a packet to be completed
        if(ulTaskNotifyTake(pdTRUE, portMAX_DELAY)){
            //If the acquiring task starts to form another packet immediatly after waking up this task, wait for that packet to be completed.
            //If that happens, bt_task will have a notification right after that packet forms
            //(the notification resulting from the formation of that 2nd packet that made the bt task wait in this semaphore)
            //and that pending notification is to send something that was already sent (that 2nd packet). Hence this task will think that there's already something
            //to send in the new active_snd_buff, where there isn't. So there's a need to check if bt_task is trying to send an empty buffer.
            xSemaphoreTake(active_snd_buff_mutex, portMAX_DELAY);
                if(snd_buff_idx[active_snd_buff] == 0){             //Check if there's actually something to send (explained above)
                    xSemaphoreGive(active_snd_buff_mutex);
                    continue;
                }
                sending_snd_buff = active_snd_buff;
                active_snd_buff = !active_snd_buff;     //Swap the active buffer in order to send the filled buffer
            xSemaphoreGive(active_snd_buff_mutex);

            //gettimeofday(&begin, NULL);

            if(btWrite(bt_client, snd_buff_idx[sending_snd_buff], snd_buff[sending_snd_buff]) == GEN_ERR){
                //So that the task doesn't wait for the bt successful write
                xSemaphoreGive(bt_send_ready_sem);
            }

            #if(_DEBUG_ == 1)
                for(uint8_t i = 0; i < snd_buff_idx[sending_snd_buff]; i++){
                    DEBUG_PRINT_I("app_main: Bt data sent", "Byte %d: %d", i, snd_buff[sending_snd_buff][i]);
                }
                DEBUG_PRINT_I("app_main: Bt data sent", "Total bytes sent:%d", snd_buff_idx[sending_snd_buff]);
                printf("\n");
            #endif

            //Clear the recently sent buffer
            memset(snd_buff[sending_snd_buff], 0, snd_buff_idx[sending_snd_buff]);
            snd_buff_idx[sending_snd_buff] = 0;

            //printf("Packets so far:%d\n", packet_cnt);    //TODO
            
            //Wait for the write to be completed in order to not congest the sends
            xSemaphoreTake(bt_send_ready_sem, portMAX_DELAY);
            
            //gettimeofday(&end, NULL); 
            //printf("Time elapsed %f s\n", ((end.tv_sec - begin.tv_sec) + ((end.tv_usec - begin.tv_usec)/1000000.0)));
        }else{
            DEBUG_PRINT_W("app_main", "ulTaskNotifyTake timed out!");
        }
    }    
}
 
//Task that adc reads using adc1, it's also the main task of CPU1 (APP CPU)
void acqAdc1Task(){
    uint8_t aux_buff[MAX_LIVE_MODE_PACKET_SIZE]; 
    uint8_t* rx_data_ads = NULL;

    spi_transaction_t ads_trans;
    spi_transaction_t *ads_rtrans;

    //Init Timer 0_1 (timer 1 from group 0) and register it's interupt handler
    timerGrpInit(TIMER_GROUP_USED, TIMER_IDX_USED, timerGrp0Isr);

    //Config all possible adc channels
    initAdc(ADC_RESOLUTION);
    gpioInit();
    //TODO: Tirar IO_21: só está aqui para dar ground ao ads
    gpio_set_level(GPIO_NUM_21, 0);

    //24 status bits + 24 bits x 2 channels = 9bytes required. But DMA buffer needs to be 32bit aligned
    rx_data_ads = heap_caps_malloc(3*sizeof(uint32_t), MALLOC_CAP_DMA);  
    memset(rx_data_ads, 0, 9);
    adsInit();
    adsSetupRoutine();
    adsSetSamplingRate(250);
    adsConfigureChannels(1);
    memset(&ads_trans, 0, sizeof(ads_trans));   //zero out the transaction
    ads_trans.length = 72;                   //send nothing
    ads_trans.rxlength = 72;                //24 status bits + 24 bits x 2 channels
    ads_trans.tx_buffer = NULL;             //skip write phase
    ads_trans.rx_buffer = rx_data_ads;

    /*
    while(1){
        gpio_set_level(GPIO_NUM_27, 1);
        gpio_set_level(GPIO_NUM_14, 1);
        vTaskDelay(1000/portTICK_RATE_MS);
        gpio_set_level(GPIO_NUM_27, 0);
        gpio_set_level(GPIO_NUM_14, 0);
        vTaskDelay(1000/portTICK_RATE_MS);
    }*/
    
    while(1){
        spi_device_queue_trans(ads_spi_handler, &ads_trans, portMAX_DELAY);
        if(ulTaskNotifyTake(pdTRUE, portMAX_DELAY)){
            //gettimeofday(&begin, NULL);
            
            acquireAdc1Channels(aux_buff);
            calcCrc(aux_buff);
            spi_device_get_trans_result(ads_spi_handler, &ads_rtrans, portMAX_DELAY);
            uint8_t* recv_ads = ads_rtrans->rx_buffer;
            int swag = (recv_ads[3] << 16) | ((uint8_t)recv_ads[4] << 8) | (recv_ads[5]);
            printf("Raw:%d, Voltage:%f\n", swag, (double)swag*(3.3/16777216));
            

            xSemaphoreTake(active_snd_buff_mutex, portMAX_DELAY);
                //Check if active snd_buff is full
                if(snd_buff_idx[active_snd_buff] + packet_size >= MAX_BUFFER_SIZE){
                    xSemaphoreGive(active_snd_buff_mutex);
                    DEBUG_PRINT_W("acqAdc1Task", "Sending buffer is full, cannot acquire");
                    continue;
                }
                memcpy(snd_buff[active_snd_buff]+snd_buff_idx[active_snd_buff], aux_buff, packet_size);
                snd_buff_idx[active_snd_buff] += packet_size;
            xSemaphoreGive(active_snd_buff_mutex);
                
            //Wake up bt_send_task in order to send new data
            xTaskNotifyGive(bt_send_task);
            //Cleanup aux vector, in order to have a clean vector for the next packet formation
            memset(aux_buff, 0, MAX_LIVE_MODE_PACKET_SIZE);

            //packet_cnt++;       //TODO
            
            
            //gettimeofday(&end, NULL);
            //printf("Time elapsed %f\n", ((end.tv_sec - begin.tv_sec) + ((end.tv_usec - begin.tv_usec)/1000000.0)));
        }else{
            DEBUG_PRINT_W("acqAdc1", "ulTaskNotifyTake timed out!");
        }
    }
}

void acqI2cTask(){
    /*uint16_t heart_rate;
    uint16_t oxygen;
    uint8_t confidence;*/
    uint32_t test;

    i2cMasterInit();
    MAX32664_Init();    
    if(MAX32664_Config()){
        DEBUG_PRINT_E("MAX32664_Config", "Config failed");
    }

    //Init Timer 1_1 (timer 1 from group 1) and register it's interupt handler
    timerGrpInit(TIMER_GRP_ACQ_I2C, TIMER_IDX_ACQ_I2C, timerGrp1Isr);
    timerStart(TIMER_GRP_ACQ_I2C, TIMER_IDX_ACQ_I2C, ACQ_I2C_SAMPLE_RATE);

    while(1){
        if(ulTaskNotifyTake(pdTRUE, portMAX_DELAY)){
            
            gettimeofday(&begin, NULL); 
            while((end.tv_sec - begin.tv_sec) + ((end.tv_usec - begin.tv_usec)/1000000.0) < 0.08){
                gettimeofday(&end, NULL);
                test++;
                vTaskDelay(10/portTICK_RATE_MS);
            }
            //printf("Time elapsed %f s\n", ((end.tv_sec - begin.tv_sec) + ((end.tv_usec - begin.tv_usec)/1000000.0)));

            /*MLX90614_GetTempObj(MLX90614_DEFAULT_ADDRESS, &(i2c_sensor_values.temp_obj), &(i2c_sensor_values.temp_obj_int));
            MLX90614_GetTempAmb(MLX90614_DEFAULT_ADDRESS, &(i2c_sensor_values.temp_amb), &(i2c_sensor_values.temp_amb_int));
            MAX32664_GetBPM(&heart_rate, &oxygen, &confidence, &(i2c_sensor_values.status));
            if(confidence >= CONFIDENCE_THRESHOLD){
                i2c_sensor_values.heart_rate = heart_rate;
                i2c_sensor_values.oxygen = oxygen;
                i2c_sensor_values.confidence = confidence;
            }*/

            //printf("BPM:%d, SpO2:%d, Confidence:%d, Status:%d, Temp Object:%.1f, Temp Ambient:%.1f\n", i2c_sensor_values.heart_rate, i2c_sensor_values.oxygen, i2c_sensor_values.confidence, i2c_sensor_values.status, i2c_sensor_values.temp_obj, i2c_sensor_values.temp_amb);
        }else{
            DEBUG_PRINT_W("acqI2cTask", "ulTaskNotifyTake timed out!");
        }
    }
}