#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/timer.h"
#include "com.h"
#include "adc.h"
#include "macros.h"
#include "timer.h"
#include "main.h"
#include "gpio.h"
#include "spi.h"

//Processes the buffer recieved in the bluetooth event
void processRcv(uint8_t* buff, int buff_size){
    uint8_t cmd = buff[0] & 0b00000011;
    uint32_t aux = 1;
    uint8_t i;

    if(buff[0] == 1){
        return;
    }

    if(live_mode){
        if(!buff[0]){
            stopAcquisition();
        }
    }else{                                                      //If in idle mode
        if(cmd == 0b01){                                        //Set live mode
            selectChsFromMask(buff);
            timerStart(TIMER_GROUP_USED, TIMER_IDX_USED, sample_rate);
            ledc_set_freq(LEDC_SPEED_MODE_USED, LEDC_LS_TIMER, LEDC_LIVE_PWM_FREQ);
            adsStart();
            live_mode = 1;
        }else if(cmd == 0b11){                                  //Configuration command
            if(!((buff[0] >> 2) & 0b00000011)){                 //Set sample rate
                for(i = 0; i < (buff[0] >> 6); i++){
                    aux *= 10;
                }
                sample_rate = aux;
                DEBUG_PRINT_W("processRcv", "Sampling rate recieved: %dHz", sample_rate);
            }else if(((buff[0] >> 2) & 0b00000011) == 0b10){    //Send device status
                sendStatusPacket();
            }else if(((buff[0] >> 2) & 0b00000011) == 0b01){    //Send firmware version string
                sendFirmwareVersionPacket();
            }
        }else if(!cmd){                                         //Set battery threshold

        }
    }
}

void selectChsFromMask(uint8_t* buff){
    int i;
    int channel_number = DEFAULT_ADC_CHANNELS;

    //Reset previous active chs
    num_active_chs = 0;

    //Select the channels that are activated (with corresponding bit equal to 1)
    for(i = 1 << (DEFAULT_ADC_CHANNELS+NUM_UNUSED_BITS_FOR_CH_MASK-1); i > NUM_UNUSED_BITS_FOR_CH_MASK; i >>= 1){
        if(buff[0] & i){
            //Store the activated channels into the respective acq_config.channels array
            active_chs[num_active_chs] = channel_number-1;
            num_active_chs++;
            DEBUG_PRINT_I("selectChsFromMask", "Channel A%d added", channel_number-1);
        }
        channel_number--;
    }
    packet_size = packet_size_num_chs[num_active_chs];
}

void stopAcquisition(void){
    timerPause(TIMER_GROUP_USED, TIMER_IDX_USED);
    ledc_set_freq(LEDC_SPEED_MODE_USED, LEDC_LS_TIMER, LEDC_IDLE_PWM_FREQ);
    live_mode = 0;
    crc_seq = 0;
    adsStop();
}

void sendStatusPacket(){
    uint8_t crc = 0;
    uint8_t i;

    xSemaphoreTake(active_snd_buff_mutex, portMAX_DELAY);
        
        // -------------------Bytes 0 - 11-------------------------------------------------
        *(uint16_t*)(snd_buff[active_snd_buff]) = i2c_sensor_values.oxygen;
        *(uint16_t*)(snd_buff[active_snd_buff]+2) = i2c_sensor_values.heart_rate;
        *(uint16_t*)(snd_buff[active_snd_buff]+4) = (uint16_t)i2c_sensor_values.confidence;
        *(uint16_t*)(snd_buff[active_snd_buff]+6) = (uint16_t)i2c_sensor_values.status;
        *(uint16_t*)(snd_buff[active_snd_buff]+8) = i2c_sensor_values.temp_obj_int;
        *(uint16_t*)(snd_buff[active_snd_buff]+10) = i2c_sensor_values.temp_amb_int;

        //-----------------------Calc CRC -------------------------------------------------

        //calculate CRC (except last byte (seq+CRC) )
        for(i = 0; i < STATUS_PACKET_SIZE-1; i++){
            // calculate CRC nibble by nibble
            crc = crc_table[crc] ^ (snd_buff[active_snd_buff][i] >> 4);
            crc = crc_table[crc] ^ (snd_buff[active_snd_buff][i] & 0x0F);
        }

        //calculate CRC for last byte (I1|I2|O1|O2|CRC)
        crc = crc_table[crc] ^ (crc_seq & 0x0F);
        crc = (0) | crc_table[crc];                 //TODO: Onde está 0, meter os valores de I1|I2|O1|O2

        //store CRC and Seq in the last byte of the packet
        snd_buff[active_snd_buff][STATUS_PACKET_SIZE-1] = crc;

        //----------------------------Store packet size-------------------------------------
        snd_buff_idx[active_snd_buff] += STATUS_PACKET_SIZE;

    xSemaphoreGive(active_snd_buff_mutex);

    //Wake up bt_send_task in order to send new data
    xTaskNotifyGive(bt_send_task);      
}

void sendFirmwareVersionPacket(){
    xSemaphoreTake(active_snd_buff_mutex, portMAX_DELAY);

        memcpy(snd_buff[active_snd_buff], FIRMWARE_VERSION_STR, strlen(FIRMWARE_VERSION_STR)+1);

        //----------------------------Store packet size-------------------------------------
        snd_buff_idx[active_snd_buff] += strlen(FIRMWARE_VERSION_STR)+1;

    xSemaphoreGive(active_snd_buff_mutex);

    //Wake up bt_send_task in order to send new data
    xTaskNotifyGive(bt_send_task);      
}