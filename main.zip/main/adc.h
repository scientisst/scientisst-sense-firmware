#ifndef _ADC_H
#define _ADC_H

#include <stdio.h>
#include "driver/adc.h"
#include "esp_adc_cal.h"

#define ADC_RESOLUTION ADC_WIDTH_BIT_10
#define ADC_RES_VALUE 10                    //ADC Resolution Value: Tem que ser o valor indicado por ADC_RESOLUTION

#define A0_ADC_CH   ADC1_CHANNEL_0  //GPIO36
#define A1_ADC_CH   ADC1_CHANNEL_3  //GPIO39
#define A2_ADC_CH   ADC1_CHANNEL_4  //GPIO32
#define A3_ADC_CH   ADC1_CHANNEL_5  //GPIO33
#define A4_ADC_CH   ADC1_CHANNEL_6  //GPIO34
#define A5_ADC_CH   ADC1_CHANNEL_7  //GPIO35

#define MAX_BUFFER_SIZE 128
#if (MAX_BUFFER_SIZE > 256)
    #error "MAX_BUFFER_SIZE needs to be less or equal than 256 because of iterators (uint8_t i) are just 8bit long"
#endif

#define DEFAULT_SAMPLE_RATE 1 //In Hz
#define MAX_LIVE_MODE_PACKET_SIZE 8

void configAdc(int adc_index, int adc_resolution, int adc_channel);
void initAdc(uint8_t adc_resolution);
void IRAM_ATTR acquireAdc1Channels(uint8_t* frame);
void IRAM_ATTR calcCrc(uint8_t* frame);

#define CALC_BYTE_CRC(_crc, _byte, _crc_table)({\
    (_crc) = _crc_table[(_crc)] ^ ((_byte) >> 4);     \
    (_crc) = _crc_table[(_crc)] ^ ((_byte) & 0x0F);   \
})

#define READ_ADC1(value, channel)({\
    (value) = adc1_get_raw((channel));       \
})

#define READ_ADC2(value, channel)({\
    adc2_get_raw((channel), ADC_RESOLUTION, &(value));       \
})

/*#define READ_ADC(adc, value, channel)({\
    (READ_ADC##adc)((value), (channel));       \
})*/

#endif